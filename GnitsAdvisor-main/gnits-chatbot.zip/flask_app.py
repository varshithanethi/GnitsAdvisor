from flask import Flask, render_template, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from dotenv import load_dotenv
import os
import logging
from werkzeug.middleware.proxy_fix import ProxyFix
from services.data_fetcher import GNITSDataFetcher
from apscheduler.schedulers.background import BackgroundScheduler
import atexit
import json

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__, static_url_path='/static')
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

# Security configurations
app.secret_key = os.getenv("SECRET_KEY", "gnits-chat-assistant-secret")
app.config["SESSION_COOKIE_SECURE"] = True
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

# Database configuration
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", "sqlite:///chat.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize database
db = SQLAlchemy(app)

# Initialize CORS
CORS(app, resources={
    r"/*": {
        "origins": ["https://gnits.ac.in", "http://localhost:5000", "https://your-app-name.herokuapp.com"],
        "methods": ["GET", "POST"],
        "allow_headers": ["Content-Type"]
    }
})

# Initialize data fetcher
data_fetcher = GNITSDataFetcher()

# Create scheduler for automatic updates
scheduler = BackgroundScheduler()
scheduler.add_job(func=lambda: data_fetcher.update_faq_data(app), 
                 trigger="interval", 
                 hours=24)  # Update daily
scheduler.start()

# Shut down scheduler when app stops
atexit.register(lambda: scheduler.shutdown())

# Your existing FAQ_RESPONSES dictionary here
FAQ_RESPONSES = {
    "student": {
        "admission": {
            "What are the eligibility criteria?": """
### B.Tech Admission Requirements
- Completed 10+2 with PCM subjects
- Qualify in TG-EAMCET examination
- Merit-based admission through counseling
- AICTE approved program
            """,
            "How to apply?": """
### Application Process
1. Qualify in TG-EAMCET
2. Attend counseling by TSCHE
3. Choose GNITS based on rank
4. Complete admission formalities
            """
        },
        "courses": {
            "What courses are offered?": """
### B.Tech Programs
- Computer Science and Engineering (CSE)
- Information Technology (IT)
- Electronics and Communication Engineering (ECE)
- Electrical and Electronics Engineering (EEE)
- Electronics and Telematics Engineering (ETM)
- CSE (AI & ML)
- CSE (Data Science)

### M.Tech Programs
- Computer Science and Engineering
- Computer Networks & Information Security
- Digital Electronics and Communication
- Power Electronics & Electric Drives
- Wireless & Mobile Communications
            """,
            "What is the fee structure?": """
### Fee Structure 2023-24
- Category A & B (JEE): ₹1,00,000/year
- Category B (NRI): USD 5,000/year
- Additional JNTUH fees applicable
            """
        }
    }
    # Add other categories similarly
}

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    data = request.json
    query = data.get('query', '').lower()
    user_type = data.get('user_type', 'general')
    
    response = "I'm sorry, I don't have specific information about that query."
    
    if user_type in FAQ_RESPONSES:
        for category in FAQ_RESPONSES[user_type]:
            for question, answer in FAQ_RESPONSES[user_type][category].items():
                if query.lower() in question.lower():
                    response = answer
                    break
    
    return jsonify({
        "content": response,
        "type": "markdown"
    })

@app.route('/data_status')
def data_status():
    try:
        with open(data_fetcher.cache_file) as f:
            cache = json.load(f)
        return jsonify({
            "status": "success",
            "last_updated": cache['last_updated']
        })
    except:
        return jsonify({
            "status": "error",
            "message": "Could not retrieve update status"
        })

if __name__ == '__main__':
    try:
        # Initialize database
        with app.app_context():
            db.create_all()
        
        # Initial data fetch
        data_fetcher.update_faq_data(app)
        
        # Server configuration
        port = int(os.environ.get("PORT", 8080))  # Changed to use environment variable
        host = '0.0.0.0'  # Allow external connections
        
        # Print access URLs
        print("\n=== GNITS FAQ Assistant Server ===")
        print(f"Local access: http://localhost:{port}")
        print(f"Network access: http://10.10.8.52:{port}")
        print("Press CTRL+C to quit\n")
        
        # Run the server
        app.run(
            host=host,
            port=port,
            debug=True,
            threaded=True,
            use_reloader=True
        )
    except Exception as e:
        print(f"\nError starting server: {str(e)}")